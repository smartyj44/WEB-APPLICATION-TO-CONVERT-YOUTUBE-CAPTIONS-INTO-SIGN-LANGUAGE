<?php
/*
	List of words not to be included in ISL
*/

$blockedwords = array("am",
					  "are",
					  "is",
					  "was",
					  "were",
					  "be",
					  "being",
					  "been",
					  "have",
					  "has",
					  "had",				
					  "does",
					  "did",
					  "could",
					  "should",
					  "would",
					  "can",
					  "shall",
					  "will",
					  "may",
					  "might",
					  "must",
					  "let");
?>