-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2019 at 07:59 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `isl_dataset`
--
DROP DATABASE IF EXISTS `isl_dataset`;
CREATE DATABASE IF NOT EXISTS `isl_dataset` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `isl_dataset`;

-- --------------------------------------------------------

--
-- Table structure for table `captionsdata`
--

DROP TABLE IF EXISTS `captionsdata`;
CREATE TABLE `captionsdata` (
  `caption_name` varchar(30) NOT NULL,
  `caption_path` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `captionsdata`
--

INSERT INTO `captionsdata` (`caption_name`, `caption_path`) VALUES
('xlBmdFORhZ8.srt', 'captions/xlBmdFORhZ8.srt'),
('U-SPrjbeElU.srt', 'captions/U-SPrjbeElU.srt'),
('W15yKKbHE80.srt', 'captions/W15yKKbHE80.srt'),
('bnpfjEHF-NU.srt', 'captions/bnpfjEHF-NU.srt'),
('pdUKug8XahU.srt', 'captions/pdUKug8XahU.srt');

-- --------------------------------------------------------

--
-- Table structure for table `fingerspelling`
--

DROP TABLE IF EXISTS `fingerspelling`;
CREATE TABLE `fingerspelling` (
  `image_id` int(11) NOT NULL,
  `image_name` varchar(30) NOT NULL,
  `image_path` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fingerspelling`
--

INSERT INTO `fingerspelling` (`image_id`, `image_name`, `image_path`) VALUES
(1, 'A', 'images/A.png'),
(2, 'B', 'images/B.png'),
(3, 'C', 'images/C.png'),
(4, 'D', 'images/D.png'),
(5, 'E', 'images/E.png'),
(6, 'F', 'images/F.png'),
(7, 'G', 'images/G.png'),
(8, 'H', 'images/H.png'),
(9, 'I', 'images/I.png'),
(10, 'J', 'images/J.png'),
(11, 'K', 'images/K.png'),
(12, 'L', 'images/L.png'),
(13, 'M', 'images/M.png'),
(14, 'N', 'images/N.png'),
(15, 'O', 'images/O.png'),
(16, 'P', 'images/P.png'),
(17, 'Q', 'images/Q.png'),
(18, 'R', 'images/R.png'),
(19, 'S', 'images/S.png'),
(20, 'T', 'images/T.png'),
(21, 'U', 'images/U.png'),
(22, 'V', 'images/V.png'),
(23, 'W', 'images/W.png'),
(24, 'X', 'images/X.png'),
(25, 'Y', 'images/Y.png'),
(26, 'Z', 'images/Z.png'),
(27, '0', 'images/0.png'),
(28, '1', 'images/1.png'),
(29, '2', 'images/2.png'),
(30, '3', 'images/3.png'),
(31, '4', 'images/4.png'),
(32, '5', 'images/5.png'),
(33, '6', 'images/6.png'),
(34, '7', 'images/7.png'),
(35, '8', 'images/8.png'),
(36, '9', 'images/9.png'),
(37, ' ', 'images/space.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fingerspelling`
--
ALTER TABLE `fingerspelling`
  ADD PRIMARY KEY (`image_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
